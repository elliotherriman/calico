This is a sample game built using Calico.

It's an (almost) carbon copy of the code used for Winter (https://communistsister.itch.io/winter), just without any of the art or audio.

A basic guide to help you get started can be found here: https://github.com/elliotherriman/calico/blob/master/documentation/getting%20started.md