This is a template to help you build games using Calico.

A basic guide to help you get started can be found here: https://github.com/elliotherriman/calico/blob/master/documentation/getting%20started.md